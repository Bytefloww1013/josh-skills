### Install command:
```
npx skills add Bytefloww1013/josh-skills
```

### Plugins

`plugins/` holds Claude Code plugins, listed in `.claude-plugin/marketplace.json`. Install one with:

```
/plugin marketplace add Bytefloww1013/josh-skills
/plugin install byte-stack@josh-skills
```

To have a repo offer it to everyone who opens it, add to that repo's `.claude/settings.json`:

```json
{
  "extraKnownMarketplaces": {
    "josh-skills": { "source": { "source": "github", "repo": "Bytefloww1013/josh-skills" } }
  },
  "enabledPlugins": { "byte-stack@josh-skills": true }
}
```

- **byte-stack**: `bmode` for bphs-connect, its playbooks, the principle skills it applies, its helper skills (`how`, `architect`, `blast-radius`, `figure-it-out`, `council-review` and more), bphs-connect's docs skills (`docs-add`, `docs-review`), `gen-issue` (files a GitHub issue with `gh`), and the `byte-agent` delegate subagent. `bmode`, `bro`, `correct` and `swarm` are manual-only (`disable-model-invocation: true`); run them as `/byte-stack:<skill>`. The rest are also model-invoked, so Claude can start them when a request fits: the principle skills, `how`, `blast-radius`, `architect`, `figure-it-out`, `in-your-own-words`, `unslop`, `technical-writing`, `typescript-best-practices`, `docs-add`, `docs-review`, `gen-issue`, `sharpen` (rewrites a prompt or skill file tighter; `--deep` also makes the task deeper) and `sol-loop` (a loop of reviews by an OpenAI Sol model, through T3 Code's `delegate_task`), and `bmode`'s playbooks run the helpers each step names. Under T3, bmode's Opening a PR step runs `sol-loop` as the code review before each push. Scouts, reviewers and implementors, `docs-review`'s finder and refuter (reviewers) and `gen-issue`'s Decider (a scout) run on the models bphs-connect's `docs/agents/sub-agent-choice.md` lists (`skills/bmode/references/t3-model-routing.md`), from the brief templates in `skills/bmode/references/briefs/`. It also ships `byte-handoff` and its Claude Code handoff guard hook (`hooks/handoff-guard.py`), which work in any repo: on every model, 35k tokens before that model's autocompact, the hook asks for a handoff (`/byte-stack:byte-handoff`) and pastes it back in after the compaction. Install byte-stack at user scope (`--scope user`) to have the guard in every project. A project that commits its own copy at `.claude/hooks/handoff-guard.py` and registers it in its `.claude/settings.json` (bphs-connect keeps one for cloud sessions, which don't install plugins) runs that copy, and the plugin's does nothing there. See `plugins/byte-stack/README.md` for Antigravity install details and unsupported hook events.
- **arch-skills**: six architecture skills for agent-built code: `architecture-decision-review` (connascence and trade-offs before a design choice), `architecture-review-report` (evidence-based report on a plan, idea or issues), `pr-erosion-check` (scope against the linked issue, agent anti-patterns) `repo-navigability-audit`, `state-machine-audit` (implicit state machines, invalid states and a findings report) and `user-flow-mapper` (a user flow as Mermaid diagrams, then a prototype and UX report). Install with `/plugin install arch-skills@josh-skills` (or `agy plugin install plugins/arch-skills` for Antigravity). Its hook reminds you to run the PR check before `gh pr create` on both Claude Code and Antigravity and never blocks it. See `plugins/arch-skills/README.md`.

To verify Antigravity installation and hook behavior in an isolated `HOME` (requires `agy` on `PATH`; exits `2` when missing):

```
python3 tests/test_antigravity_plugin_install.py
```

### BPHS

`bphs/` holds BrightPath Human Services work skills, one folder per skill.

- **bphs-ingest-cc**: turns a Chase card workbook (Transactions + Accounts tabs) into a Chase Bank bill-import CSV for QuickBooks (Bill Numbers `CHS-#####`), one line per short-code and program 600-611.
